﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ScrambledWords
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<string> wordList = new List<string> { "headphones", "laptop", "mouse", "keyboard"};
        private string word;

        public MainWindow()
        {
            InitializeComponent();
            playButton.IsEnabled = true;
        }



        private void PlayButton_Click(object sender, RoutedEventArgs e)
        {
            Random random = new Random();
            int randomIndex = random.Next(0, wordList.Count);
            string scramble;
            word = wordList[randomIndex];

            // Scramble the word
            char[] charArray = word.ToCharArray();
            for (int i = 0; i < charArray.Length; i++)
            {
                int rand = random.Next(i, charArray.Length);
                char temp = charArray[i];
                charArray[i] = charArray[rand];
                charArray[rand] = temp;
            }
            scramble = new string(charArray);

            wordLabel.Content = scramble;
        }


        private void CheckButton_Click(object sender, RoutedEventArgs e)
        {
            string userAnswer = answerTextBox.Text.ToLower();

            if (userAnswer == word)
            {
                MessageBox.Show("CORRECT", "Result", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("INCORRECT", "Result", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            answerTextBox.Clear();
        }
    }
}
